# generate_routes.py
# Generate 30 customer locations, cluster into 10 routes via KMeans
